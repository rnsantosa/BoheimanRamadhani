<?php
  $details=array();
  $details['server_host']="localhost";//server host name
  $details['mysql_name']="root";//your mysql user name
  $details['mysql_password']="";//your mysql user name
  $details['mysql_database']="probooks";//your database name
?>