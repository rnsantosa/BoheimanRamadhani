<?php

return array(
    'host' => 'localhost',
    'db_name' => 'probooks',
    'username' => 'root',
    'password' => '',
);